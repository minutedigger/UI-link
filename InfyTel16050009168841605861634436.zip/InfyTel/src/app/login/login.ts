export class Login {
    phoneNo: number;
    password: string;
}
