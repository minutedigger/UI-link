export class AddFriend {
    friendAndFamily: number;
}
